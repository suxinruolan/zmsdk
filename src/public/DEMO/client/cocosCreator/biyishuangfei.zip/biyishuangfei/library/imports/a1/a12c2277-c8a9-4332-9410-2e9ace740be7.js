"use strict";
cc._RF.push(module, 'a12c2J3yKlDMpQQLprOdAvn', 'androidSdk');
// scripte/androidSdk.js

//这个文件必须有 不然无法在安卓上运行
"use strict";

cc._RF.pop();