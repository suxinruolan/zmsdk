"use strict";
cc._RF.push(module, '31554/U+tNNWrewFQ2ruZ1w', 'tensApi');
// scripte/tensApi.js

'use strict';

/*
 * @Github: 我没有
 * @Author: 李鹏帅
 * @如果有bug，那肯定不是我的锅，嘤嘤嘤
 * @since: 2019-10-11 08:56:18
 * @lastTime: 2019-10-11 16:53:05
 * @LastAuthor: Do not edit
 * @message: gamesdk
 */
// import 'http://www.asdf.com/DCJavaScriptBridge.js';
!function (a, b) {
    "function" == typeof define && (define.amd || define.cmd) ? define(function () {
        return b(a);
    }) : b(a, !0);
}(window, function (w, flag) {

    function callhandler(asdf, name, data, callback) {
        DAWebViewJavascriptBridge.callHandler(asdf, name, data, callback);
        //    setupWebViewJavascriptBridge(function (bridge) {
        //            bridge.callHandler(asdf, name, data, callback)
        //    })
    }
    function tabel(name, callback) {
        DAWebViewJavascriptBridge.callHandler(name, callback);
    }
    var ZMIM;
    ZMIM = {
        config: function config(options) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMConfigPlugin', 'config', options, function (state, data) {
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        ready: function ready(callback) {
            if (w.DAWebViewJavascriptBridge) {
                DAWebViewJavascriptBridge.init(function (message, responseCallback) {
                    var data = { 'Javascript Responds': 'Wee!' };
                    responseCallback(data);
                });
                callback();
            } else {
                document.addEventListener('WebViewJavascriptBridgeReady', function () {
                    DAWebViewJavascriptBridge.init(function (message, responseCallback) {
                        var data = { 'Javascript Responds': 'Wee!' };
                        responseCallback(data);
                    });
                    callback();
                }, false);
            }
        },
        error: function error(res) {},
        request: function request(url, method, data) {
            return new Promise(function (resolve, reject) {
                var dataJson = {};
                dataJson.url = url;
                dataJson.method = method;
                dataJson.data = data;
                callhandler('ZIMRequestPlugin', 'request', dataJson, function (state, data) {
                    cc.log('state', state);
                    cc.log('data', data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        getUserInfo: function getUserInfo() {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMUserInfoPlugin', 'getUserInfo', function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        showShareAlert: function showShareAlert() {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMShareAlertPlugin', 'showShareAlertView', function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        gameResurrection: function gameResurrection(id) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMGoldPlugin', 'gameResurrection', { 'id': id }, function (state, data) {
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        gameResetResurrection: function gameResetResurrection() {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMGoldPlugin', 'gameResetResurrection', function (state, data) {
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        getWorldRanking: function getWorldRanking(page, count) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMRankingPlugin', 'getWorldRanking', { 'page': page, 'count': count }, function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        getTeamRanking: function getTeamRanking(page, count) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMRankingPlugin', 'getTeamRanking', { 'page': page, 'count': count }, function (state, data) {
                    console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        getFriendRanking: function getFriendRanking(page, count) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMRankingPlugin', 'getFriendRanking', { 'page': page, 'count': count }, function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        saveGameScore: function saveGameScore(score) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMRankingPlugin', 'saveGameScore', { 'score': score }, function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        showTips: function showTips(message) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMShareAlertPlugin', 'showTips', { 'message': message }, function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        showJOJOAlert: function showJOJOAlert(message) {
            return new Promise(function (resolve, reject) {
                callhandler('ZIMShareAlertPlugin', 'showJOJOAlert', { 'message': message }, function (state, data) {
                    // console.log('state', state, data);
                    if (state === 0) {
                        resolve(data);
                    } else {
                        reject(data);
                    }
                });
            });
        },
        currentScreenState: function currentScreenState(res) {
            return new Promise(function (resolve, reject) {
                tabel('currentScreenState', function (state, data) {
                    // console.log('state', state, data);
                    resolve(data);
                });
            });
        }
    }, flag && (w.zmim = w.ZMIM = ZMIM), ZMIM;
});

cc._RF.pop();