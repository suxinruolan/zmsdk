"use strict";
cc._RF.push(module, '5df48gaA05NIoo/J4tNrUuV', 'branchmag2');
// scripte/branchmag2.js

'use strict';

cc.Class({
    extends: cc.Component,
    properties: {
        branchpreL: {
            default: null,
            type: cc.Prefab
        },
        branchpreR: {
            default: null,
            type: cc.Prefab
        }
    },
    onLoad: function onLoad() {
        this.poolL = new cc.NodePool('branch');
        this.poolR = new cc.NodePool('branch');
        for (var i = 0; i < 100; i++) {
            this.poolL.put(cc.instantiate(this.branchpreL));
            this.poolR.put(cc.instantiate(this.branchpreR));
        }
    },
    start: function start() {
        this.schedule(function () {
            if (!this.node.parent.getComponent('play').isGameOver && this.poolL.size() > 0 && this.poolR.size() > 0) {
                this.node.parent.getComponent('play').createBranch(this.node, this.poolL, this.poolR);
            }
        }, 0.5);
    },
    update: function update(dt) {
        if (this.node.parent.getComponent('play').isGameOver) {
            this.node.parent.getComponent('play').offTouch(this.node);
        }
        if (!this.node.parent.getComponent('play').isGameOver) {
            this.node.parent.getComponent('play').touchStar(this.node);
        }
    }
});

cc._RF.pop();