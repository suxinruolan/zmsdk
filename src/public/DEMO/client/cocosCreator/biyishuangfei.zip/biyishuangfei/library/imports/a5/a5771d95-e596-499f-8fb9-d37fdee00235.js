"use strict";
cc._RF.push(module, 'a57712V5ZZJn4+503/e4AI1', 'data');
// scripte/data.js

"use strict";

// http://192.168.199.195:3001/game?type=biyishuangfei&cljljl=rrt&wydtt=game&gameId=5d493cb3c6c5ee0001b1a7d3
var a = {
    data: {
        userInfo: null,
        page: 1
    }
};
module.exports = a;

cc._RF.pop();