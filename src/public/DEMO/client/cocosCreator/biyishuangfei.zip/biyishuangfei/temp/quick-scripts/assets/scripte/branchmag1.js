(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripte/branchmag1.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c8b88ku6A9MKLMYPBj3vbiN', 'branchmag1', __filename);
// scripte/branchmag1.js

'use strict';

cc.Class({
    extends: cc.Component,
    properties: {
        branchpreL: {
            default: null,
            type: cc.Prefab
        },
        branchpreR: {
            default: null,
            type: cc.Prefab
        }
    },
    onLoad: function onLoad() {
        this.poolL = new cc.NodePool('branch');
        this.poolR = new cc.NodePool('branch');
        for (var i = 0; i < 100; i++) {
            this.poolL.put(cc.instantiate(this.branchpreL));
            this.poolR.put(cc.instantiate(this.branchpreR));
        }
    },
    start: function start() {
        this.schedule(function () {
            if (!this.node.parent.getComponent('play').isGameOver && this.poolL.size() > 0 && this.poolR.size() > 0) {
                this.node.parent.getComponent('play').createBranch(this.node, this.poolL, this.poolR);
            }
        }, 0.5);
    },
    update: function update(dt) {
        if (this.node.parent.getComponent('play').isGameOver) {
            this.node.parent.getComponent('play').offTouch(this.node);
        }
        if (!this.node.parent.getComponent('play').isGameOver) {
            this.node.parent.getComponent('play').touchStar(this.node);
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=branchmag1.js.map
        