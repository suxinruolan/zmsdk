(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripte/data.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a57712V5ZZJn4+503/e4AI1', 'data', __filename);
// scripte/data.js

"use strict";

// http://192.168.199.195:3001/game?type=biyishuangfei&cljljl=rrt&wydtt=game&gameId=5d493cb3c6c5ee0001b1a7d3
var a = {
    data: {
        userInfo: null,
        page: 1
    }
};
module.exports = a;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=data.js.map
        