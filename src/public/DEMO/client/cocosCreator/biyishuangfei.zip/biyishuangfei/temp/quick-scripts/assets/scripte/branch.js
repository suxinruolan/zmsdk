(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripte/branch.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '64105DfwEZEbJLpmYqDWmzD', 'branch', __filename);
// scripte/branch.js

'use strict';

cc.Class({
    extends: cc.Component,
    properties: {},
    onLoad: function onLoad() {},
    init: function init(pool) {
        this.pool = pool;
    },
    start: function start() {},
    update: function update(dt) {
        var num = cc.find('Canvas').getComponent('play').score / 10 > 10 ? 10 : cc.find('Canvas').getComponent('play').score / 10;

        if (this.node.y < -this.node.height || cc.find('Canvas').getComponent('play').isGameOver) {
            if (!cc.find('Canvas').getComponent('play').isGameOver) {
                cc.find('Canvas').getComponent('play').score += 0.5;
                cc.find('Canvas').getChildByName('score').getComponent(cc.Label).string = parseInt(cc.find('Canvas').getComponent('play').score);
            }
            this.pool.put(this.node);
        }
        this.node.y -= 5 + num;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=branch.js.map
        